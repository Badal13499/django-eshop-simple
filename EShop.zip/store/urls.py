from django.contrib import admin
from django.urls import path
from .views import Index, Registration, Login, logout, cart, Checkout, Order
from store.middlewares.authenticate import auth_middleware

urlpatterns = [
    path('', Index.as_view(), name='homepage'),
    path('signup', Registration.as_view()),
    path('signIn', Login.as_view(), name='signIn'),
    path('logout', logout, name='logout'),
    path('cart', cart, name='cart'),
    path('checkout', Checkout.as_view(), name='checkout'),
    path('orders', auth_middleware(Order.as_view()), name='orders'),

]
