from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import make_password, check_password
from .models import Product, Category, Customer, Orders
from django.views import View

from django.core.exceptions import ObjectDoesNotExist
from django.utils.decorators import method_decorator

# Create your views here.
class Index(View):

    def get(self, request):

        products = None
        category = Category.get_All_Category()
        categoryID = request.GET.get('cat')
        if categoryID:
            products = Product.get_All_Category_by_id(category_id=categoryID)
        else:
            products = Product.get_All_Products()
        params = {'products': products,
                  'category': category}
        print(request.session.get('email'))
        return render(request, 'index.html', params)

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(product)
            if quantity:
                if remove:
                    if quantity <= 1:
                        cart.pop(product)
                    else:
                        cart[product] = quantity - 1

                else:
                    cart[product] = quantity + 1
            else:
                cart[product] = 1
        else:
            cart = {}
            cart[product] = 1

        request.session['cart'] = cart
        print(request.session['cart'])
        return redirect('homepage')



class Registration(View):

    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        fname = request.POST.get('fname')
        lname = request.POST.get('lname')
        phone = request.POST.get('phone')
        email = request.POST.get('email')
        password = request.POST.get('password')
        conpassword = request.POST.get('conpassword')

        value = {'fname': fname, 'lname': lname, 'phone': phone, 'email': email}

        if password == conpassword:
            customer = Customer(fname=fname, lname=lname, phone=phone, email=email, password=password)
            if customer.isExists():
                error_msg = "Email already registered"
                return render(request, 'signup.html', {'flag': error_msg, 'value': value})
            else:
                customer.password = make_password(customer.password)
                customer.register()
                return redirect('homepage')

        else:
            error_msg = "Password does not match"
            return render(request, 'signup.html', {'flag': error_msg, 'value': value})


class Login(View):
    return_url = None

    def get(self, request):
        Login.return_url = request.GET.get('return_url')
        return render(request, 'signIn.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')

        customer = Customer.getCustomerByEmail(email)
        if customer:
            if check_password(password,customer.password):
               request.session['customer_id'] = customer.id
               request.session['email'] = customer.email

               if Login.return_url:
                    return HttpResponseRedirect(Login.return_url)
               else:
                   Login.return_url = None
                   return redirect('homepage')
            else:
                error_msg = "Email or Password invalid!!"
        else:
            error_msg = "Email or Password invalid!!"
        return render(request, 'signIn.html', {'flag':error_msg})


def logout(request):
    request.session.clear()
    return redirect('login')


def cart(request):
    ids = list(request.session.get('cart').keys())
    products = Product.get_product_by_id(ids)
    # print(products)
    return render(request, 'cart.html', {'products': products})

class Checkout(View):
    def post(self, request):
        address = request.POST.get('address')
        phone = request.POST.get('phone')
        customer = request.session.get('customer_id')
        cart = request.session.get('cart')
        products = Product.get_product_by_id(list(cart.keys()))
        print(address, phone, customer, cart, products)

        for product in products:
            order = Orders(customer=Customer(id=customer), product=product, price=product.price, address=address, phone=phone,quantity=cart.get(str(product.id)))
            order.placeOrder()
        request.session['cart'] = {}
        return redirect('cart')

class Order(View):

    def get(self, request):
        customer = request.session.get('customer_id')
        orders = Orders.get_order_by_customer(customer)
        # print(orders)
        orders = orders.reverse()
        return render(request, 'orders.html', {'orders': orders})