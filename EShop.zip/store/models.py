from django.db import models
import datetime
# Create your models here.


class Category(models.Model):
    name = models.CharField(max_length=20)


    @staticmethod
    def get_All_Category():
        return Category.objects.all()


    def __str__(self):
        return self.name


class Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    desc = models.CharField(max_length=200, default='', null=True, blank=True)
    image = models.ImageField(upload_to='uploads/products/')

    @staticmethod
    def get_All_Products():
        return Product.objects.all()

    @staticmethod
    def get_product_by_id(ids):
        return Product.objects.filter(id__in = ids)



    @staticmethod
    def get_All_Category_by_id(category_id):
        if category_id:
            return Product.objects.filter(category = category_id)
        else:
            return Product.get_All_Products()

    def __str__(self):
        return self.name


class Customer(models.Model):
    fname = models.CharField(max_length=50)
    lname = models.CharField(max_length=50)
    phone = models.IntegerField(default=0)
    email = models.EmailField(max_length=500)
    password = models.CharField(max_length=500)

    def register(self):
        self.save()

    def isExists(self):
        if Customer.objects.filter(email=self.email):
          return True
        return False

    @staticmethod
    def getCustomerByEmail(email):
        try:
            return Customer.objects.get(email=email)
        except:
            return False

    def __str__(self):
        return self.fname + self.lname


class Orders(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.IntegerField(default=1)
    price = models.IntegerField()
    date = models.DateField(default=datetime.datetime.today)
    address = models.CharField(max_length=5000, default="", blank=True)
    phone = models.CharField(max_length=15, default="", blank=True)
    status = models.BooleanField(default=False)

    def placeOrder(self):
        self.save()

    @staticmethod
    def get_order_by_customer(customer_id):
       return Orders.objects.filter(customer = customer_id).order_by('date')